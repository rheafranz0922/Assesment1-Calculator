package com.example.calculatorassesment

import android.os.Bundle
import android.graphics.drawable.ColorDrawable
import android.widget.Button
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class Calculator1 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_calculator1)

        val colorPaletteButton: Button = findViewById(R.id.button)
        colorPaletteButton.setOnClickListener {
            displayColorPalette()

        }
    }

    private fun displayColorPalette() {
        val colorPaletteButton: Button = findViewById(R.id.button)
        val colorDrawable = colorPaletteButton.background as? ColorDrawable
        val color = colorDrawable?.color ?: 0
        val colorPaletteName = getColorPaletteName(color)
        Toast.makeText(applicationContext, colorPaletteName, Toast.LENGTH_SHORT).show()
    }

    private fun getColorPaletteName(color: Int): String {
        return when (color) {
            ContextCompat.getColor(this, R.color.palette1) -> "Palette 1"
            ContextCompat.getColor(this, R.color.palette2) -> "Palette 2"
            // Add more cases for other palette colors as needed
            else -> "Unknown Palette"
        }
    }
}
